# -*- coding: utf-8 -*-
"""
Created on Mon May  9 10:58:50 2022

@author: 
"""
###import des bibliothèques###
import random as rd
import math
import tkinter as tk
import time 
import webbrowser
import os


###initialisation de variables###
choix_option=True
n=10
nuage=algorithme=0
cbg='white' 
cln='black'
cpte='red'
cpta='black'
cpg='white' 
L=[]
B=[]
go = True

#############################################
#### Algorithmes de génération de nuages ####
#############################################
def generation_nuage_random(n,nuage):
    
    while len(nuage)!=n:
        nuage.append([rd.randint(50,min(hauteur,largeur)-50),rd.randint(50,min(hauteur,largeur)-50)])
    return(nuage)


def generation_nuage_carree(n,nuage):
     taille=rd.randint(50,min(hauteur,largeur)//3)  ###on détermine la taille du carré
     while len(nuage)!=n:
         x=rd.randint(taille,min(hauteur,largeur)-taille)
         y=rd.randint(taille,min(hauteur,largeur)-taille)
         nuage.append([x,y])
     return(nuage)


def generation_nuage_circulaire(n,nuage):
    
    rayon=rd.randint(100,min(hauteur,largeur)/2) ###on détermine la taille du cercle
    while len(nuage)!=n:
        x=min(hauteur,largeur)/2+rd.randint(-rayon,rayon)
        y=min(hauteur,largeur)/2+rd.randint(-rayon,rayon)
        if abs(distance([min(hauteur,largeur)/2,min(hauteur,largeur)/2],[x,y]))<=rayon:
            nuage.append([x,y])  
    return(nuage)
  
          
def generation_nuage_triangulaire(n,nuage):
    
    p1=[rd.randint(0,min(hauteur,largeur)/2),min(hauteur,largeur)*3/4]
    p2=[rd.randint(min(hauteur,largeur)/2,min(hauteur,largeur)),min(hauteur,largeur)*3/4] ###on créer le triangle où les points vont être généré 
    p3=[min(hauteur,largeur)/2,rd.randint(0,min(hauteur,largeur)/2)]
    angle1=ang(p1,p2,p3)
    angle2=ang(p2,p3,p1)
    angle3=ang(p3,p1,p2)
    while len(nuage)!=n:
        p=[rd.randint(0,min(hauteur,largeur)),rd.randint(0,min(hauteur,largeur))]
        if angle1>=ang(p1,p2,p) and angle2>=ang(p2,p3,p) and angle3>=ang(p3,p1,p):
            nuage.append(p)
    return nuage


###########################################################################
#### Sous-programmes nécessaire à la génération de l'enveloppe convexe ####
###########################################################################

### Calcul de l'angle entre un vecteurs et l'axe de abscisses 
def angle(p1,p2):
    return  math.atan2((-p1[1]+p2[1]),(-p1[0]+p2[0]))
###

### Calcul de la distance entre deux points 
def distance(p1,p2):
    return math.sqrt((-p1[1]+p2[1])**2+(-p1[0]+p2[0])**2)
###

### Calcul de l'angle entre 3 points 
def ang(a,b,c):
    ang= (math.atan2(c[1]-b[1], c[0]-b[0]) - math.atan2(a[1]-b[1], a[0]-b[0]))
    if ang>math.pi:         #
        ang-=2*math.pi      #
    if ang<-math.pi:        # on place l'angle entre -pi et pi
        ang+=2*math.pi      #
    return ang              #
###

### Calcul le produit vectoriel de AB et AC
def produit_vect(A,B,C):
    V1=[B[0]-A[0],B[1]-A[1]]
    V2=[C[0]-A[0],C[1]-A[1]]
    prdv=V2[0]*V1[1]-V1[0]*V2[1]
    return prdv
###    
 
### Détermine l'indice d'un point dans une liste
def index(L,points):
    place=0
    for i in range(len(L)):
        if points==L[i]:
            place=i
    return place
###

### Détermine si trois points sont alignés dans une liste et en suprime un le cas échéant
def aligné(L):
    b=[]
    for i in range(len(L)):
        if produit_vect(L[i-2],L[i-1],L[i])==0:
            b.append(i-1)
    for k in range(len(b)):
        L.pop(b[0]+k)
    return L
###

### Tri une liste en fonction des places de ces composants dans L'Enveloppe
def triage(pts,Enveloppe):
    B=[]
    while len(pts)!=0:
       num=0
       indice=index(Enveloppe,pts[num])
       
       for k in range(len(pts)):
           
         if index(Enveloppe,pts[k])<indice:
             
            indice=index(Enveloppe,pts[k])
            num=k
            
       B.append(pts.pop(num))
       
    return(B)
###   


########################################################
#### Algorithme de création des enveloppes convexes ####
########################################################

def papier_cadeau(L):

        #on met le premier point au minimum
    compteur=0
    n=0
    compteur+=1
    L.sort()
    compteur+=1
    M=[]
    compteur+=1
    M.append(L[0])
    compteur+=1
    ############################
    p=[]
    compteur+=1
    angle=-1.57
    compteur+=1
    p.append(L[0])
    compteur+=1
    memoire=L[0]
    compteur+=1
    memoire_max=L[len(L)-1]
    compteur+=1

    
    while (p != [max(L)]):  #premier passage de gauche à droite en passant par le bas
        compteur+=1
        del L[n]
        compteur+=1
        for i in range (len(L)):
            orientation=(math.atan2((-p[0][1]+L[i][1]),(-p[0][0]+L[i][0])))
            compteur+=1
            if (angle<orientation and -1.57<orientation<1.57):
                angle=orientation
                compteur+=1
                n=i
                compteur+=1
            compteur+=1
        p=[L[n]]
        compteur+=1
        M.append(p[0])
        compteur+=1
        angle=-1.57
        compteur+=1

    N=[]
    compteur+=1
    L.append(memoire_max)
    compteur+=1
    angle=1.57
    compteur+=1
    p=[]
    compteur+=1
    p.append(memoire)
    compteur+=1
    N.append(memoire)
    compteur+=1
    
    
    while (p != [max(L)]):   #Second passage de droite à gauche en passant par le haut
        compteur+=1
        del L[n]
        compteur+=1
        for i in range (len(L)):
            orientation=(math.atan2((-p[0][1]+L[i][1]),(-p[0][0]+L[i][0])))
            compteur+=1
            if (angle>orientation and -1.57<orientation<1.57):
                angle=orientation
                compteur+=1
                n=i
                compteur+=1
            compteur+=1
        p=[L[n]]
        compteur+=1
        N.append(p[0])
        compteur+=1
        angle=1.57
        compteur+=1
    del N[-1]
    compteur+=1
    N.reverse()
    compteur+=1
    finale=M+N
    compteur+=1
    print(compteur)
    return finale

def méthode_incrémental(L):

    compteur=0
    Enveloppe=[]
    compteur+=1
    B=[]
    compteur+=1
    for i in range(len(L)):
        B.append(L[i])
        compteur+=1
    B.sort()
    compteur+=1
    
    Enveloppe.append(B.pop(0))
    compteur+=1
    Enveloppe.append(B.pop(0))
    compteur+=1                     ### Création du premier triangle
    Enveloppe.append(B.pop(0))
    compteur+=1

    if angle(Enveloppe[0],Enveloppe[1])>angle(Enveloppe[0],Enveloppe[2]):
        a=Enveloppe[2]
        compteur+=1
        Enveloppe[2]=Enveloppe[1]
        compteur+=1
        Enveloppe[1]=a 
        compteur+=1
    compteur+=1                  ###Tri du premier triangle pour le parcourir dans le sens directe
    
    
    if produit_vect(Enveloppe[0],Enveloppe[1],Enveloppe[2])==0:
        Enveloppe[2]=B.pop(-1)
        compteur+=1
    compteur+=1
    
    while len(B)!=0:
        compteur+=1
        Enveloppe=aligné(Enveloppe)
        compteur+=1
        pts=[]
        compteur+=1
        for i in range(len(Enveloppe)):
            if produit_vect(Enveloppe[i-1],Enveloppe[i],B[0])>=0:   ### Calcul des produits vectoriels pour savoir quels sommets supprimer
                pts.append(Enveloppe[i-1])
                compteur+=1
            compteur+=1
        pts=triage(pts,Enveloppe)
        compteur+=1

                    
        if len(pts)==0:     ### il n'y a aucun produit vectoriel >=0 : le point est dans L'Enveloppe

            B.pop(0)
            compteur+=1
        compteur+=3
            
        if len(pts)==1:     ### il y a un produit vectoriel >+0 : le point est un nouveaux sommet
            a=index(Enveloppe,pts[0])
            compteur+=1
            Enveloppe.insert(a+1,B[0])
            compteur+=1
            B.pop(0)
            compteur+=1
        
        if len(pts)>1 :   ### il y a plus d'un produit vectoriel >=0 : il y a donc des sompmets à supprimer
            pts.pop(0)
            compteur+=1
            a=index(Enveloppe,pts[0])
            compteur+=1
            b=0
            compteur+=1
            while (len(pts)!=0):
                compteur+=1
                for i in range(len(Enveloppe)):
                    if pts[0]==Enveloppe[i]:
                        b=i
                        compteur+=1
                    compteur+=1
                Enveloppe.pop(b)
                compteur+=1
                pts.pop(0)
                compteur+=1
            Enveloppe.insert(a,B[0])
            compteur+=1
            B.pop(0)
            compteur+=1
    Enveloppe.append(Enveloppe[0])
    compteur+=1
    print(compteur)
    
    return Enveloppe

def Angle_polaire (L):
    
    Compteur = 0
    L.sort()      #On cherche le point le plus à gauche
    Compteur+=1
    M=[]
    Compteur+=1
    M.append(L[0])
    Compteur+=1
    L.pop(0)
    Compteur+=1
    while len(L)!=0:
        Compteur+=1
        angle_min=angle(M[0],L[0]) 
        Compteur+=1
        p=0
        Compteur+=1
        for i in range(1,len(L)):
            Compteur+=1
            if angle_min>angle(M[0],L[i]):
                Compteur+=1
                p=i
                Compteur+=1                                   #On Trie les points en fonction de l'angle 
                angle_min=angle(M[0],L[i])                    #qu'ils forment avec le point de départ
            Compteur+=1
            if angle_min==angle(M[0],L[i]):
                Compteur+=1
                if distance(M[0],L[p])>distance(M[0],L[i]):
                    p=i
                    Compteur+=1
                    angle_min=angle(M[0],L[i])
                    Compteur+=1
        M.append(L[p])
        Compteur+=1
        L.pop(p)
        Compteur+=1
    Enveloppe=[]
    Compteur+=1
    Enveloppe.append(M.pop(0))
    Compteur+=1
    Enveloppe.append(M.pop(0))
    Compteur+=1
    
    while len(M)!=0:
        Compteur+=1
        if ang(Enveloppe[-2],Enveloppe[-1],M[0])<0: #on regarde le signe des angles formé par trois points
                                                    #si le signe change , le point ne fait pas partie de l'enveloppe
            Enveloppe.append(M.pop(0))
            Compteur+=1    
        elif ang(Enveloppe[-2],Enveloppe[-1],M[0])>=0:
            
            Compteur+=1
            Enveloppe.pop(-1)
    Compteur+=1
    Enveloppe.append(Enveloppe[0])
    Compteur+=1
    print(Compteur)
    return Enveloppe

######################################
#### Initialisation de la fenêtre ####
######################################


wnd = tk.Tk()
largeur= wnd.winfo_screenwidth()
hauteur= wnd.winfo_screenheight()
minimum_point=min(hauteur,largeur)

#############################################
#### Algorithme dessinant les enveloppes ####
#############################################


### Dessin non-instantané 
def dessiner_polygone2(a,points):
    global go
    go = False
    for k in range(len(points)):
            cnv.create_oval(points[k][0]-2,points[k][1]-2,points[k][0]+2,points[k][1]+2,fill=cpta)
    for i in range (len(a)-1):
        cnv.create_oval(a[i][0]-3,a[i][1]-3,a[i][0]+3,a[i][1]+3,fill=cpte)
        cnv.create_line(a[i][0],a[i][1],a[i+1][0],a[i+1][1],fill=cln)
        time.sleep(0.2)
        cnv.update()
    cnv.create_polygon(a,fill=cpg)
    go = True
    dessiner_polygone3(a,points)
###

### Dessin instantané
def dessiner_polygone3(a,points):
    if go ==True:
     cnv.create_polygon(a,fill=cpg)
     for k in range(len(points)):
        cnv.create_oval(points[k][0]-2,points[k][1]-2,points[k][0]+2,points[k][1]+2,fill=cpta)
     for i in range (len(a)-1):
        cnv.create_line(a[i][0],a[i][1],a[i+1][0],a[i+1][1],fill=cln)
        cnv.create_oval(a[i][0]-3,a[i][1]-3,a[i][0]+3,a[i][1]+3,fill=cpte)
###   

#########################################
#### Options pour la fenêtre Tkinter ####
#########################################

### Relance une nouvelle génération de nuage
def relancer(event):
    global go,B,L,n,generation
    if go==True:
    
        cnv.delete("all")
        L=[]
        L=generation(n,L)
        B=[]
        for i in range(len(L)):
            B.append(L[i])
        liste_enveloppe=creer_polygone(L)
        dessiner_polygone2(liste_enveloppe,B)
        cnv.update()
        cnv.pack()
###

### Anime la fenêtre et fait bouger les points
def initialiser ():
    global move
    move=True
    animer()
    
def stop ():
    global move
    move = False
    animer()
    
def animer ():
    
    global L,B
    if (move==True):
        
        cnv.delete("all")
        for i in range (len(B)):
            decalage=[-10,10]
            x_modif=rd.choice(decalage)
            y_modif=rd.choice(decalage)
            if ((B[i][0]+x_modif<minimum_point) and ((B[i][1]+y_modif)<minimum_point) and ((B[i][0]+x_modif>0) and (B[i][1]+y_modif>0))):
                B[i][0]=B[i][0]+x_modif
                B[i][1]=B[i][1]+y_modif
        L=[]
        for i in range(len(B)):           
             L.append(B[i])
        liste_enveloppe=creer_polygone(L)
        dessiner_polygone3(liste_enveloppe,B)
        cnv.pack()
    
        cnv.after(200,animer)
        cnv.mainloop()
###

### Ajoute un point sur la fenêtre
def Ajouter_point(event):
    global B,go,minimum_point
    if go ==True:
     if (event.x<minimum_point and event.y<minimum_point)and(event.x>0 and event.y>0):
      cnv.delete("all")
      L=B
      L.append([event.x,event.y])
      B=[]
      for i in range(len(L)):
         B.append(L[i])
      liste_enveloppe=creer_polygone(L)
      dessiner_polygone3(liste_enveloppe,B)
      cnv.pack()
      cnv.mainloop()
###   

### Supprime le point  séléctionner par l'utilisateur
def supp_point(event):
    global B ,go
    if go ==True:
        for i in range(len(B)):
            if B[i][0]-10<event.x<B[i][0]+10 and B[i][1]-10<event.y<B[i][1]+10:
                a=i
        B.pop(a)
        L=[]
        for i in range(len(B)):
            L.append(B[i])
        liste_enveloppe=creer_polygone(L)
        cnv.delete("all")
        dessiner_polygone3(liste_enveloppe,B)
###         
            
    
  
### Deplace un point maintenue par l'utilisateur et le fixe losrqu'il est relaché
def Deplacer_point(event):
    
    global x0, y0
    x0, y0 = event.x, event.y
    x=len(B)
    for k in range (x):
        if abs(B[k][0]-x0)<5 and abs(B[k][1]-y0)<5:

            cnv.bind('<Motion>', mouvement_point)

            cnv.bind('<ButtonRelease>', fixer_point)
                  
def mouvement_point(event):
    
    cnv.coords(x0, y0, event.x, event.y)

def fixer_point(event):
    global placer
    a=len(B)
    for k in range (a):
       if abs(B[k][0]-x0)<5 and abs(B[k][1]-y0)<5:
           del B[k]
           break
        
    cnv.delete("all")
    B.append([event.x,event.y])
    L=[]
    
    for i in range(len(B)):
        L.append(B[i])
        
    liste_enveloppe=creer_polygone(L)
    dessiner_polygone3(liste_enveloppe,B)
    cnv.pack()
    cnv.unbind('<ButtonRelease>', fixer_point)
    cnv.unbind('<Motion>', mouvement_point)
###

### Relance la fenêtre d'acceuil
def retour_menu():
    global wnd,intro
    wnd2.destroy()
    wnd = tk.Tk()
    
    wnd.title("Convex Hull")
    wnd.resizable(False, False)


    intro=tk.Canvas(wnd,width=min(largeur,hauteur), height=min(hauteur,largeur), bg='white')
    Titre=tk.Label(wnd,text="CONVEX HULL",cursor="plus",font=('bahnschrift 20 underline'),bg="white")
    Titre.place(x=10,y=100)

    Logo=tk.PhotoImage(file='Images\logo2.png')
    photo1=tk.Label(wnd,image = Logo ,borderwidth=0,cursor="hand2")
    photo1.place(x=10,y=20)


    photo1.bind("<Button-1>", lambda e:open_url('https://eseo.fr/'))
    photo1.bind('<Enter>', logo_enterHoover)
    photo1.bind('<Leave>', lambda e:msgboxLogo.destroy())


    Illustration=tk.PhotoImage(file='Images\Illustration2.png')
    photo2=tk.Label(wnd,image = Illustration,borderwidth=0)
    photo2.place(x=150,y=150)
    
    PDF=tk.PhotoImage(file='Images\PDF2.png')
    photo3=tk.Label(wnd,image = PDF ,borderwidth=0,cursor="hand2")
    photo3.place(x=800,y=20)
    
    photo3.bind("<Button-1>", lambda e:open_file('Dossiers\Enveloppes_convexes.pdf'))
    photo3.bind('<Enter>', PDF_enterHoover)
    photo3.bind('<Leave>', lambda e:msgboxPDF.destroy())
        
    Lancerpgm=tk.Button(wnd,text='Run program',command=lancer)
    Lancerpgm.place(x=10,y=150)
            


    Titre=tk.Label(wnd,text="OPTIONS :",cursor="plus",font=('bahnschrift 10 underline'),bg="white")
    Titre.place(x=10,y=180)

    OPT1=tk.Button(wnd,text='Number of points',command=Nombre_de_points)
    OPT1.place(x=10,y=210)
    
    OPT2=tk.Button(wnd,text='Colors',command=choix_couleur)
    OPT2.place(x=10,y=240)
    
    OPT3=tk.Button(wnd,text='Type of Scatter graph',command=choix_nuage)
    OPT3.place(x=10,y=270)
    
    OPT4=tk.Button(wnd,text='Algorithm',command=choix_algorithme)
    OPT4.place(x=10,y=300)
    


    intro.pack()
    wnd.mainloop()
###           

############################################
#### Génération de la fenêtre de dessin ####
############################################

### Création de la fenêtre
def lancer():
 global cnv,L,B,n,nuage,generation,wnd2,choix_option,algorithme,creer_polygone
 if choix_option==True:
  L=[]
  
  pgm=[generation_nuage_random,generation_nuage_carree,generation_nuage_circulaire,generation_nuage_triangulaire]
  algo=[papier_cadeau,Angle_polaire,méthode_incrémental]
  
  creer_polygone=algo[algorithme]
  generation=pgm[nuage]             ### Initialisation des paramètres de simulation
  L=generation(n,L)
  B=[]
  
  wnd.destroy()
  wnd2=tk.Tk()
  wnd2.resizable(False,False)
  wnd2.title('Convex Hull')
 
  cnv = tk.Canvas(wnd2, width=min(largeur,hauteur), height=min(hauteur,largeur), bg=cbg) 
 
    
  def clavier_enterHoover(e):   ### Explication des commandes
    global msgboxclavier
    msgboxclavier = tk.Label(wnd2,text='Commands : \n P : Place a point \n D : Delete a point \n Left Click : Move a point \n Enter : Restart the program', font='Helvetica 10 italic')
    msgboxclavier.place(x=100, y=10)
    
  clavier=tk.PhotoImage(file='Images\clavier.png')
  photo_clavier=tk.Label(wnd2,image = clavier ,borderwidth=0,cursor="hand2")
  photo_clavier.place(x=20,y=20)
  
  photo_clavier.bind('<Enter>', clavier_enterHoover)
  photo_clavier.bind('<Leave>', lambda e:msgboxclavier.destroy())
 
    
  btn=tk.Button(wnd2,text="Animate the convex hull",command=initialiser)
  btn.place(x=20,y=120)
  
  btn=tk.Button(wnd2,text="Stop the animation",command=stop)
  btn.place(x=20,y=160)
  
  btn=tk.Button(wnd2,text="Back to the menu",command=retour_menu)
  btn.place(x=20,y=80)
  
  
  cnv.bind('<Return>',relancer)
  cnv.focus_set()
  cnv.bind('<p>',Ajouter_point)
  cnv.bind('<d>',supp_point)
  cnv.bind('<ButtonPress>',Deplacer_point)
  cnv.update()
  cnv.pack()
  
 
  for i in range(len(L)):
        B.append(L[i])                   ### Création du nuage
  liste_enveloppe=creer_polygone(L)
  
  dessiner_polygone2(liste_enveloppe,B)  ### Dessin du nuage
  cnv.update()
  cnv.pack()
 
  wnd2.mainloop()
###

#############################
#### Options utilisateur ####
#############################

### Choix de L'algorithme
def choix_algorithme():
    global choix_option,algorithme
    if choix_option==True:
        
        def validation(opt,valider,label,ListeAlgorithme,selection_algo):
            global algorithme,choix_option
            algorithme=ListeAlgorithme.index(selection_algo.get())
            valider.destroy()
            label.destroy()
            opt.destroy()
            choix_option=True
            
            
        choix_option=False  
        valider=tk.Button(wnd,text='Apply',command=lambda : validation(opt,valider,label,ListeAlgorithme,selection_algo)) 
        valider.place(x=10,y=815)
        ListeAlgorithme = ["Gift-Wrap Method","Polar Angle Method","Incremental Methodppp"] 
        selection_algo = tk.StringVar()
        selection_algo.set(ListeAlgorithme[0])

        opt = tk.OptionMenu(wnd, selection_algo, *ListeAlgorithme)
        label = tk.Label(text="Select the algorithm you want the program to use : ")
        label.place(x=10,y=700)
        opt.place(x=10,y=720)
###
 
### Choix d'un style de nuage 
def choix_nuage():
    global choix_option,nuage
    if choix_option == True:
        
        def validation(liste_button,valider,label):
         global choix_option,nuage
         nuage=eval(selection_nuage.get())
         print(nuage)
         for w in liste_button:
            w.destroy()
         valider.destroy()
         label.destroy()
         choix_option=True
         
         
         return
        
        choix_option=False
        valider=tk.Button(wnd,text='Apply',command=lambda : validation(liste_button,valider,label)) 
        valider.place(x=10,y=815)
        photo_nuage_random=tk.PhotoImage(file='Images\lenuage_random.png')
        photo_nuage_carré=tk.PhotoImage(file='Images\lenuage_carré.png')
        photo_nuage_triangulaire=tk.PhotoImage(file='Images\lenuage_triangulaire.png')
        photo_nuage_circulaire=tk.PhotoImage(file='Images\lenuage_rond.png')
        selection_nuage=tk.StringVar()
        selection_nuage.set(0)
        nuages=((photo_nuage_random,0),
                (photo_nuage_carré,1),
                (photo_nuage_circulaire,2),
                (photo_nuage_triangulaire,3))
        label = tk.Label(text="Select a type of scatter graph : ")
        label.place(x=10,y=700)
        numéro_bouton=0
        liste_button=[]
        for nuage in nuages:
            Bt = tk.Radiobutton(wnd,image=nuage[0],value=nuage[1],variable=selection_nuage)
            Bt.place( x=10+(numéro_bouton*125) ,y=720)
            numéro_bouton+=1
            liste_button.append(Bt)
        photo1=tk.label(wnd,text='').place(x=10,y=720)
###

### On choisit le nombre de points dans le nuage   
def Nombre_de_points():
    global n,choix_option
    def validation(echelle,valider):
     global choix_option,n
     n=echelle.get()
     if n<3:
        n=3
     echelle.destroy()
     valider.destroy()
     choix_option=True
     
    if choix_option==True:
     choix_option=False
     global n
     echelle=tk.Scale(wnd,from_=0,to=500,orient='horizontal',resolution=5,tickinterval=25,length=500,label='Number of points')
     echelle.place(x=10,y=750)
     valider=tk.Button(wnd,text='Apply',command=lambda : validation(echelle,valider)) 
     valider.place(x=465,y=750)
###  
       
### On choisit un set de couleurs   
def choix_couleur():
    global choix_option
    if choix_option==True:
     choix_option=False
     def apercu():
      A=selection_couleur.get()
      Liste=[]
      Liste.append(A[0:7])
      Liste.append(A[8:15])
      Liste.append(A[16:23])
      Liste.append(A[24:31])
      Liste.append(A[32:39])
     
         
      for i in range(len(Liste)):
        intro.create_rectangle(400+(50*i),720,400+(50*(i+1)),750,fill=Liste[i])
    
      intro.update()
    
     def validation2(BT1,liste_button,BT2,label):
      global cbg,cln,cpte,cpta,cpg  ,choix_option
      A=selection_couleur.get()
      cbg=A[0:7]
      cln=A[8:15]
      cpte=A[16:23]
      cpta=A[24:31]
      cpg=A[32:39]
      BT1.destroy()
      BT2.destroy()
      label.destroy()
      intro.create_rectangle(400,720,650,750,fill='white',outline='white')
      for i in range (len(liste_button)):
         Bt=liste_button[i]
         Bt.destroy()
      choix_option=True
    
     selection_couleur = tk.StringVar()
     colors=(('set 1',['#000000','#FFFFFF','#6fa8dc','#cfe2f3','#0b5394']),
             ('set 2',['#000000','#FFFFFF','#e06666','#f4cccc','#990000']),
             ('set 3',['#000000','#FFFFFF','#c27ba0','#ead1dc','#741b47']),
             ('set 4',['#FFFFFF','#000000','#FF0000','#000000','#0099ff']),
             ('set 5',['#FFFFFF','#000000','#FF0000','#000000','#EA902A']),
             ('set 6',['#FFFFFF','#000000','#FF0000','#000000','#15CA35']))
     label = tk.Label(text="Select a set of colors : ")
     label.place(x=10,y=700)
     numéro_bouton=0
     liste_button=[]
     for color in colors : 
        Bt = tk.Radiobutton(wnd,text=color[0],value=color[1],variable=selection_couleur)
        Bt.place( x=10+(numéro_bouton*50) ,y=720)
        numéro_bouton+=1
        liste_button.append(Bt)
     BT1=tk.Button(wnd ,text='Overview', command=apercu)
     BT1.place(x=10,y=750)
     BT2=tk.Button(wnd ,text='Apply', command=lambda : validation2(BT1,liste_button,BT2,label))
     BT2.place(x=70,y=750)
###   


#################################
#### Interface Homme-Machine ####
#################################

def logo_enterHoover(e):
    global msgboxLogo
    msgboxLogo = tk.Label(wnd,text="ESEO's site", font='Helvetica 10 italic')
    msgboxLogo.place(x=20, y=80)

def PDF_enterHoover(e):
    global msgboxPDF
    msgboxPDF = tk.Label(wnd,text="Project's subject", font='Helvetica 10 italic')
    msgboxPDF.place(x=800, y=150)
    
def open_url(url):
   webbrowser.open_new_tab(url)
   
def open_file(file):
    os.startfile(file)

    
###########################################
#### Lancement de la fenêtre d'acceuil ####
###########################################

wnd.title("Convex Hull")
wnd.resizable(False, False)


intro=tk.Canvas(wnd,width=min(largeur,hauteur), height=min(hauteur,largeur), bg='white')
Titre=tk.Label(wnd,text="Convex Hull",cursor="plus",font=('bahnschrift 20 underline'),bg="white")
Titre.place(x=10,y=100)

Logo=tk.PhotoImage(file='Images\logo2.png')
photo1=tk.Label(wnd,image = Logo ,borderwidth=0,cursor="hand2")
photo1.place(x=10,y=20)


photo1.bind("<Button-1>", lambda e:open_url('https://eseo.fr/'))
photo1.bind('<Enter>', logo_enterHoover)
photo1.bind('<Leave>', lambda e:msgboxLogo.destroy())


Illustration=tk.PhotoImage(file='Images\Illustration2.png')
photo2=tk.Label(wnd,image = Illustration,borderwidth=0)
photo2.place(x=150,y=150)

PDF=tk.PhotoImage(file='Images\PDF2.png')
photo3=tk.Label(wnd,image = PDF ,borderwidth=0,cursor="hand2")
photo3.place(x=800,y=20)

photo3.bind("<Button-1>", lambda e:open_file('Dossiers\Enveloppes_convexes.pdf'))
photo3.bind('<Enter>', PDF_enterHoover)
photo3.bind('<Leave>', lambda e:msgboxPDF.destroy())

Lancerpgm=tk.Button(wnd,text='Run program',command=lancer)
Lancerpgm.place(x=10,y=150)



Titre=tk.Label(wnd,text="OPTIONS :",cursor="plus",font=('bahnschrift 10 underline'),bg="white")
Titre.place(x=10,y=180)

OPT1=tk.Button(wnd,text='Number of points',command=Nombre_de_points)
OPT1.place(x=10,y=210)

OPT2=tk.Button(wnd,text='Colors',command=choix_couleur)
OPT2.place(x=10,y=240)

OPT3=tk.Button(wnd,text='Type of Scatter graph',command=choix_nuage)
OPT3.place(x=10,y=270)

OPT4=tk.Button(wnd,text='Algorithm',command=choix_algorithme)
OPT4.place(x=10,y=300)



intro.pack()
wnd.mainloop()


